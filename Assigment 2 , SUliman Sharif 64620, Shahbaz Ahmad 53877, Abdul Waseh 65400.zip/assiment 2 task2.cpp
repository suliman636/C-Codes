#include <iostream>
using namespace std;
class charQueue {
private:
    char* queuearray;
    int queueSize;
    int front;
    int rear;
    int currentSize;   

public:
    charQueue(int size) {
        queueSize = size;
        queuearray = new char[size];
        front = 0;
        rear = -1;
        currentSize = 0;   // initially empty
    }

    bool isFull() {
        return (currentSize == queueSize);
    }

    bool isEmpty() {
        return (currentSize == 0);
    }

    void enqueue(char ch) {
        if (isFull()) {
            cout << "Queue is full!" << endl;
        } else {
            rear = (rear + 1) % queueSize;
            queuearray[rear] = ch;
            currentSize++;   
        }
    }

    char dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty!" << endl;
            return '\0';
        } else {
            char ch = queuearray[front];
            front = (front + 1) % queueSize;
            currentSize--;   
            return ch;
        }
    }


   void display() {
        if (isEmpty()) {
            cout << "Queue is empty..." << endl;
        } else {
            cout << "Queue elements: ";
            int index = front;
            for (int i = 0; i < currentSize; i++) {
                cout << queuearray[index] << " ";
                index = (index + 1) % queueSize;
            }
            cout << endl;
        }
    }
    ~charQueue(){
    	delete[] queuearray;
	}

};






int main() {
    int size;
    cout << "Enter queue size: ";
    cin >> size;

    charQueue user(size);

    cout << "Enter " << size << " characters to enqueue:" << endl;
    for (int i = 0; i < size; i++) {
        char ch;
        cin >> ch;
        user.enqueue(ch);
    }

    user.display();

    cout << "\nDequeuing all elements from queue:" << endl;
    for (int i = 0; i < size; i++) {
        cout << "Dequeued: " << user.dequeue() << endl;
    }

    user.display();

    return 0;
}