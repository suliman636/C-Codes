#include <iostream>
using namespace std;

class charstack{
	private:
char* stackarray;
int stacksize;
int top;
public:
charstack(int size){
	stacksize=size;
	stackarray=new char[size];
	 top= -1;
}

void push(char ch){
	if(isfull()){
		cout<<"stack is full."<<endl;
	}
	else{
		top++;
		stackarray[top]=ch;
		
	}

}

char pop(){
	if (isemtey()){
		cout<<"stack is emtey"<<endl;
		return '\0';
	}
	else{
	char ch=stackarray[top];
	top--;
	return ch;
}

}
bool isfull(){
	return (top==stacksize-1);
}

bool isemtey(){
	return (top==-1);
}
void display(){
	if(isemtey()){
		cout<<"stack is emtey ..."<<endl;
	}
	
	else{
		cout<<"stack element "<<endl;
		for(int i=0;i<=top;i++){
		cout<<	stackarray[i]<<" ";
		}
		cout<<endl;
	}
}
~charstack() {
        delete[] stackarray;
    }

	
};
int main(){
	
	int size;
	cout<<"Enter size :";
	cin>>size;
	charstack user(size);
	cout<<"Enter "<<size <<" character to posh :"<<endl;
	for(int i=0;i<size;i++){
		char ch;
		cin>>ch;
		if (user.isfull()) {
            cout << "Stack is full! No more input accepted." << endl;
            break;
        }
		user.push(ch);	
	}
	user.display();
cout << "\nPopping all elements from stack:" << endl;
    for (int i = 0; i < size; i++) {
        cout << "Popped: " << user.pop() << endl;
    }
    user.display();
    return 0;
		
	}
