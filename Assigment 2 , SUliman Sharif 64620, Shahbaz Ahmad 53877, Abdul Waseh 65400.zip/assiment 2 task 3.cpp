#include <iostream>
#include <string>
using namespace std;

class CharStack {
private:
    int top;
    int size;
    char *arr;

public:
    CharStack(int s) {
        size = s;
        arr = new char[size];
        top = -1;
    }

    void Push(char c) {
        if (top == size - 1)
            cout << "Stack Full" << endl;
        else
            arr[++top] = c;
    }

    char Pop() {
        if (top == -1)
            return '\0';
        else
            return arr[top--];
    }

    char Top() {
        if (top == -1)
            return '\0';
        else
            return arr[top];
    }

    bool isEmpty() {
        return (top == -1);
    }

    ~CharStack() {
        delete[] arr;
    }
};

bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

bool isOperand(char c) {
    return (!isOperator(c) && c != '(' && c != ')');
}

int precedence(char op) {
    if (op == '^') return 3;
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}

string manualReverse(string str) {
    string rev = "";
    for (int i = str.length() - 1; i >= 0; i--) {
        rev += str[i];
    }
    return rev;
}

string infixToPrefix(string infix) {
    infix = manualReverse(infix);

    for (int i = 0; i < infix.length(); i++) {
        if (infix[i] == '(')
            infix[i] = ')';
        else if (infix[i] == ')')
            infix[i] = '(';
    }

    CharStack opStack(100);
    string postFixString = "";

    for (int i = 0; i < infix.length(); i++) {
        char c = infix[i];

        if (isOperand(c)) {
            postFixString += c;
        }
        else if (c == '(') {
            opStack.Push(c);
        }
        else if (c == ')') {
            while (!opStack.isEmpty() && opStack.Top() != '(')
                postFixString += opStack.Pop();
            opStack.Pop();
        }
        else if (isOperator(c)) {
            while (!opStack.isEmpty() && precedence(opStack.Top()) > precedence(c))
                postFixString += opStack.Pop();
            opStack.Push(c);
        }
    }

    while (!opStack.isEmpty())
        postFixString += opStack.Pop();

    return manualReverse(postFixString);
}

int main() {
    string infix;
    cout << "\n\n\tEnter an Infix expression: ";
    getline(cin, infix);

    string prefix = infixToPrefix(infix);

    cout << "\n\tThe Prefix expression is: " << prefix << endl;
    return 0;
}
